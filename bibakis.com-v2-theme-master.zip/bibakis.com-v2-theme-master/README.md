# bibakis.com-v2-theme
The theme which powers Bibakis.com v2. Available in HMTL &amp; WordPress editions.

What is special about this theme is that on mobile, the menu is in the bottom of the screen. This allows for easier navigation using your thumb. You can see it in action in [Bibakis.com](https://bibakis.com) or in the images below. Please download and give feedback. You can reach me at bibakisv at gmail dot com.

![Mobile menu](https://bibakis.com/wp-content/uploads/2020/08/bibakis_theme_v2_menu_open.png)

![Mobile post view](https://bibakis.com/wp-content/uploads/2020/08/WordPress-bottom-navigation.jpg)
