<div class="footer_container">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="footer_social_icons">
          <a target="_blank" href="https://twitter.com/bibakis">
            <img src="<?php echo get_stylesheet_directory_uri();?>/images/social_icons/twitter.svg">
          </a>
          <a target="_blank" href="https://www.facebook.com/bibakiscom/">
            <img src="<?php echo get_stylesheet_directory_uri();?>/images/social_icons/facebook.svg">
          </a>
          <a target="_blank" href="https://www.instagram.com/bibakis/">
            <img src="<?php echo get_stylesheet_directory_uri();?>/images/social_icons/instagram.svg">
          </a>
        </div>
      </div>
    </div>
  </div>
</div>


    <footer class="blog-footer">
      <?php wp_footer(); ?>
    </footer>


  </body>
</html>
